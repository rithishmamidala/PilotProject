package com.survey.survey.management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SurveyManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
